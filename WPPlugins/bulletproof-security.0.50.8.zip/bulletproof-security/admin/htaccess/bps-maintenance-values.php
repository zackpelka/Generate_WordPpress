<?php
# BEGIN BPS MAINTENANCE MODE
$bps_maint_countdown_timer = '';
$bps_maint_countdown_timer_color = '';
$bps_maint_time = '';
$bps_maint_retry_after = '';
$bps_maint_text = "";
$bps_maint_background_images = '';
$bps_maint_center_images = '';
$bps_maint_background_color = '';
$bps_maint_show_visitor_ip = '';
$bps_maint_show_login_link = '';
$bps_maint_login_link = '';
$bps_maint_countdown_email = '';
$bps_maint_email_to = '';
$bps_maint_email_from = '';
$bps_maint_email_cc = '';
$bps_maint_email_bcc = '';
# BEGIN BPS MAINTENANCE MODE PRIMARY SITE
$all_sites = '';
$all_subsites = '';
$primary_site_uri = '';
# END BPS MAINTENANCE MODE PRIMARY SITE
# END BPS MAINTENANCE MODE
?>