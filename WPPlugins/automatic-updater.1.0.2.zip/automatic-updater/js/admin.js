var automaticUpdaterAdmin;

( function( $ ) {

automaticUpdaterAdmin = {

	load: function() {
	},
};

} )( jQuery );

automaticUpdaterAdmin.load();
